const Footer = () => {
    return (
      <footer>
        <p>Task Manager. All rights reserved</p>
      </footer>
    );
  };
  
  export default Footer;
  