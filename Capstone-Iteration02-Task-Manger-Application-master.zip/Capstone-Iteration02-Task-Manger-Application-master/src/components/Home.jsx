// src/components/Home.jsx
const Home = () => {
    return (
      <div>
        <h2>Welcome to the Task Manager</h2>
        <p>This app helps you manage your tasks efficiently and stay organized.</p>
      </div>
    );
  };
  
  export default Home;
  