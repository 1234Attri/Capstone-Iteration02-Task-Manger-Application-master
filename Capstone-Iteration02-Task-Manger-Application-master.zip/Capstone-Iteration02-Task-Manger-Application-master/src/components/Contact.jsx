// src/components/Contact.jsx
const Contact = () => {
    return (
      <div>
        <h2>Contact Us</h2>
        <p>If you have any questions, feel free to reach out at contact@taskmanager.com.</p>
      </div>
    );
  };
  
  export default Contact;
  