const Header = () => {
    return (
      <header>
        <h1>Task Manager</h1>
      </header>
    );
  };
  
  export default Header;
  