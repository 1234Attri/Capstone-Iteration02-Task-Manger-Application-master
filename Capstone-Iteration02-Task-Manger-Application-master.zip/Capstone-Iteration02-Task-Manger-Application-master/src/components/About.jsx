// src/components/About.jsx
const About = () => {
    return (
      <div>
        <h2>About Task Manager</h2>
        <p>This app is built to help users organize their tasks in a simple, efficient way.</p>
      </div>
    );
  };
  
  export default About;
  